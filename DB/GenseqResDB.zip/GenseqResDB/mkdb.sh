/data/GensKey/Work/hanpeng/Software/blast/ncbi-blast-2.9.0+/bin/makeblastdb -dbtype nucl -parse_seqids -out card.nucl -in card.nucl.fa

